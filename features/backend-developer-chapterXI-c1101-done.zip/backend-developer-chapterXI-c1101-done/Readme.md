Azure Key Vault with Spring Boot
================================

Caso:
------

Para el laboratorio, se realizará la configuración y registro de secretos en Azure Key Vault, para después
ser consultados y acceder a la base de datos Azure SQL.

> Registrar un alquiler de bicicleta, completar el alquiler o cancelar el alquiler

<br>
La aplicación hace uso de spring boot, dependencias reactivas para acceder a la base de datos y así mismo se agrega
la dependencia para acceder a Key Vault Azure.
Puede hacer uso del laboratorio de acceso a datos reactivos con R2dbc y H2 para tomarlo como base.

![KeyVault Secrets](imgs/keyVault-Secrets.svg)

Dependencias:
------------

Requerido:

- spring boot webflux
- spring data r2dbc
- r2dbc-mssql
- azure-key-vault:2.3.8

Opcional:

- spring boot validation
- spring boot actuator
- spring boot devtools
- spring boot test


> Se debe de considerar que los componentes y configuraciones de la base de datos y el Key Vault, pueden llegar a no estar disponible por tema de pago o baja de servicio. Se recomienda realizar la implementanción de dichos componentes.
-----

Pasos (Solo se considerará la configuración Azure Key Vault):
------

1. ingresar a azure CLI o Portal Azure, y buscar el componente "Azure Active Directory"<br>
![find azure active directory](imgs/azure_1.png)

1. dentró del Active Directory, buscar en la menú lateral de la izquierda la opcción "App Registrations" <br>
![find App Registrations](imgs/azure_2.png)

1. Ahora, tienes que realizar una nuevo registro -> "New registration", este pasó es importe, ya que, es la forma
con la que se autenticará la aplicación para acceder al KeyVault. Para este pasó se asignará un nombre de la aplicación
Luego seleccionamos la opción de para las cuentas que tendrán acceso a la app. Adicional y de forma opcional podemos
ingresar el tipo de aplicación y un dominió de la app. Finalmente presionamos el botón de "Register", para realizar el registro de la App. <br>
![new registration app](imgs/azure_3.png)

1. Cuando termine de realizar el registro, se mostrará los datos del registro y de aquí obtendremos un par de datos importantes:
     1. **Application (client) ID**: AAAAA-AAAAAAA-AAAAAA-AAAAA-AAAAAA
     1. **Directory (tenat) ID**: TTTTTT-TTTTT-TTTTTTT-TTTTT
  se deben tener presente estos datos, ya que más adelante se utilizá para la autenticación de la app - spring-boot.<br>
![](imgs/azure_4.png)

1. Ahora, tenemos que generar un "client-key", para para completar la autenticación de la app.
Debemos ingresar a la opción "Certificates & Secrets" en el menú lateral izquierdo.<br>
![](imgs/azure_5.png)

1. Debemos agregar un nuevo key app "New client secret"<br>
![](imgs/azure_6.png)

1. Se debé agregar una descripón y el tiempo de vigencia del "client-key", después dar en agregar.<br>
![](imgs/azure_7.png)

1. **¡Importante!** el key generado debe de copiarse y almacernase en otro lado, ya que cuando se actualicé esta se ofuscará.<br>
![](imgs/azure_8.png)

1. El siguiente paso es agregar un KeyVault, para eso vamos al buscador e ingresar "key vault".<br>
![](imgs/azure_9.png)

1. Ahora agregamos un nuevo Keyvault.<br>
![](imgs/azure_10.png)

1. Debemos de establecer los valores que se marcan como obligario. Subscription, Resource group (se recomienda que se encuentre en un resource group distinto a donde se entra los components a los que se quiere acceder), ingresar un keyVault name, y eligir el plan se recomienda que sea el Premium. Finalmente presionamos en el botón Review + Create.<br>
![](imgs/azure_11.png)

1. Con el pasó anterior obtendremos un dato impotarte que es el DNS Name, con el cual accederemos al KeyVault, guardar este dato, que será ingresado en nuestra app.<br>
![](imgs/azure_12.png)

1. Ahora procederemos a agregar **Access Policies**, vamos a enlazar el App que hemos registrado con el KeyVault. Para realizar hacemos los siguientes pasos:
  ![](imgs/azure_12.1.png)

1. Luego hacemos clic en la opción de **Add Access Policy**.
  ![](imgs/azure_12.2.png)

1. Ahora ingresamos los siguientes valores, un Template y la applicación registrado en AD.
  ![](imgs/azure_12.3.png)

1. Seguimos los pasos, como se muestran en la siguiente imagen. (Aquí enlazamos a la aplicación)
  ![](imgs/azure_12.4.png)

1. Con los Valores establecidos presionamos el botón **Add**.
  ![](imgs/azure_12.5.png)

1. Después solo presionamos en el icono **Save**, y con eso ya tendríamos nuestra app enlazada con nuestro **KeyVault**. Debemos de validar que la aplicación se muestre en la sección inferior.
  ![](imgs/azure_12.6.png)

1. Ahora, procederemos al registro de nuestros secretos, para nuestro caso registraremos los parametros más importantes para acceder a la base de datos Azure SQL, los parametros son: el host, username, password, database name, para registrar realizaremos la siguiente acción. Ir al menú lateral izquierda y buscar la opción **"Secrets"**. <br>
![](imgs/azure_13.png)

1. dentro de la opción *Secrets* debemos presionar en el icono de **Generar/Import** para agregar un nuevo *Secrets*
![](imgs/azure_14.png)

1. El nuevo secreto se basa en un label y un valor el cual será encriptada. Así mismo podremos gestionar las fechas de activación y expiración del secreto, tambien podremos habilitar o desahabilitar según se requira. <br>
![](imgs/azure_15.png)

1. Con el pasó enterior pudimos agregar los **secrets** dentro del KeyVault. De modo que nuestro KeyVault quedará con los secrets registrados del siguiente modo. <br>
![](imgs/azure_16.png)

1. Como podemos verificar, si llegamos a ingresar a un **secret**, podemos apresiar que ya no podemos ver el valor que se le a asignado, lo unico que se llega a ver es el valor encriptado, a partir de aqui solo podemos eliminar el **secret** o realizar modificaciones, donde mantedremos un historial. <br>
![](imgs/azure_17.png)


1. Ahora realizaremos la configuración en nuestra app, agregaremos los keys generados como se muestra en el siguiente ejemplo. <br>
    ```yaml
    azure:
      keyvault:
        enabled: true # importante para que springboot autoconfiguré y realicé el pull de secretos
        uri: 'https://<NAME KEYVAULT>.vault.azure.net/' # DNS KeyVault
        client-id: <CLIENT-ID APP REGISTER AUTH>
        tenant-id: <TENANT-ID APP REGISTER AUTH>
        client-key: <KEY APP AUTH>
    ```

1. En la clase "MssqlProperties.java" se definirá las propiedades a las cuales se asignará los valores de los secret almacenados en el KeyVault. <br>
      ```java
      @Value("${application.r2dbc.name}")
      private String name;

      @Value("${application.r2dbc.url}")
      private String url;

      @Value("${application.r2dbc.username}")
      private String username;

      @Value("${application.r2dbc.password}")
      private String password;
      ```

1. Con los datos anteriores, ahora tenemos de definir los **@Beans** con los que configuraremos la conexión a la base de datos Azure SQL. Para ver detalle revisá la clase **R2dbcConfig.java**. Con la clase *MssqlProperties.java* tomaremos los valores retornados por el keyvault, ya que estos se disponibilisan en Property Enviroment del contexto de Spring y mediante **@Value** establecemos los valores a los atributos de instancia de la clase. De hay es que cuando creamos el Bean solo le pasamos las propiedades al **ConnectionFactory**.

      ```java
        @Override
        @Bean
        public ConnectionFactory connectionFactory() {
          ConnectionFactoryOptions options =
              ConnectionFactoryOptions.builder()
                  .option(DRIVER, "sqlserver")
                  .option(USER, properties.getUsername())
                  .option(PASSWORD, properties.getPassword())
                  .option(DATABASE, properties.getName())
                  .option(HOST, properties.getUrl())
                  .build();
          return ConnectionFactories.get(options);
        }
      ```
<br>

Pruebas:
--------

Debe de utilizar el collection postman para realizar las pruebas de comunicación, revisar los logs generados por la aplicación.

Cunado lenvatemos la aplicación en el log de la app, veremos que la librería de keyvault nos abstraé la funcionalidad del pull de secrets. <br>

![](imgs/result.png)


cURL:
-----

curl --location --request POST 'http://localhost:8080/bike-rental/flux/v1/rental' \
--header 'Content-Type: application/json' \
--data-raw '{
    "startDate": "2020-07-14T20:00:00",
    "origin": {
        "station": {
            "code": "S0004"
        }
    },
    "destination": {
        "station": {
            "code": "S0002"
        }
    },
    "bike": {
        "code": "K0002"
    },
    "userId": "U0001"
}'

Links:
------

- https://www.youtube.com/watch?v=Lwhu5GD5NDY (creación de resource group y key vault)
- https://docs.microsoft.com/en-us/azure/developer/java/spring-framework/configure-spring-boot-starter-java-app-with
-azure-key-vault (implementación)
- https://www.youtube.com/watch?v=QotRVUyr1_M
- https://www.youtube.com/watch?v=WYt5GiTdESI


