package pe.com.example.bikerental.models.fn03;

public class StationVo {

  private String code;

  /**
   * @return the code
   */
  public String getCode() {
    return code;
  }

  /**
   * @param code the code to set
   */
  public void setCode(String code) {
    this.code = code;
  }

}