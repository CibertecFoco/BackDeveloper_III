package pe.com.example.bikerental.business.fn03;

import pe.com.example.bikerental.models.fn03.BikeRentRequest;
import pe.com.example.bikerental.models.fn03.BikeRentResponse;
import reactor.core.publisher.Mono;

public interface BikeRentService {

  Mono<BikeRentResponse> createBikeRental(BikeRentRequest payload);

}