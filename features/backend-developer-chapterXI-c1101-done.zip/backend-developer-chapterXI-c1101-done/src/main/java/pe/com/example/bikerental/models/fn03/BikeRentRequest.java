package pe.com.example.bikerental.models.fn03;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.io.Serializable;
import java.time.LocalDateTime;

@JsonInclude(value = Include.NON_NULL)
public class BikeRentRequest implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = 6591120868471961162L;

  private LocalDateTime startDate;

  private SourceStationVo origin;

  private SourceStationVo destination;

  private BIkeVo bike;

  private String userId;

  public LocalDateTime getStartDate() {
    return this.startDate;
  }

  public void setStartDate(LocalDateTime startDate) {
    this.startDate = startDate;
  }

  public SourceStationVo getOrigin() {
    return this.origin;
  }

  public void setOrigin(SourceStationVo origin) {
    this.origin = origin;
  }

  public SourceStationVo getDestination() {
    return this.destination;
  }

  public void setDestination(SourceStationVo destination) {
    this.destination = destination;
  }

  public BIkeVo getBike() {
    return this.bike;
  }

  public void setBike(BIkeVo bike) {
    this.bike = bike;
  }

  public String getUserId() {
    return this.userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

}