package pe.com.example.bikerental.business.fn06;

import static org.springframework.data.relational.core.query.Criteria.where;
import static org.springframework.data.relational.core.query.Query.query;
import java.time.Duration;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.stereotype.Component;
import pe.com.example.bikerental.thirdparty.BikeRentalDto;
import reactor.core.publisher.Flux;

/**
 * UserRentActiveSender
 */
@Component
public class UserRentActiveSender {

  private final R2dbcEntityTemplate template;

  public UserRentActiveSender(R2dbcEntityTemplate template) {
    this.template = template;
  }

  /**
   * método que permite la consulta de los alquileres activos en la base de datos transaccional (Azure SQL)
   * @param userId identificador del cliente
   * @return Flux
   */
  public Flux<BikeRentalDto> getUserRentsActivesRents(String userId) {
    return template.select(
        query(
            where("user_id").is(userId)
                .and(where("is_canceled").isFalse()
                    .or(where("is_completed")
                        .isFalse()))
            ), BikeRentalDto.class)
            .delayElements(Duration.ofMillis(2000L));
  }

}
